/* a hack to get redhat motif to work with redhat 5.0 */

#include <locale.h>

char *_Xsetlocale(int category, const char * locale)
        __attribute__ ((weak));

char *_Xsetlocale(int category, const char * locale) {
  setlocale (category, locale);
}
